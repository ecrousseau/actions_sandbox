const run = require('./upload-release-asset');

run();
